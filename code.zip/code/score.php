<?
/*
 * Jason Ernst, UoG, 2014
 */
define('DEBUG',false);

/* order of things:
 * 1. parse cities from the cultural files
 * 2. bring in other information given those cities (crime, etc.)
 * 3. rank cities based on maximum and minimum values for various metrics
 * 4. compute score
 */

//$cities = parse_cities();
//read_province($cities);
//read_crime($cities);
//read_income($cities);
//read_unemployment($cities);
//read_rent($cities);
//$labours = parse_labour();
//map_city_to_labour($cities, $labours);
//print_cities($cities);

//foreach($labours as $labour)
//	print_labour($labour);
	
class City
{
	//data about a particular city
	public $name;			//name of city
	public $province;		//province of city
	public $long;			//longtitude of city
	public $lat;			//latitude of city
	public $population;		//total city population
	public $visible_pop;	//visible minority population
	
	//ranking stats 
	public $cultures;		//list of all the cultures in the city and their populations
	
	public $crime_severity;
	public $crime_clearance;//todo: more crime data available, may be able to add more
	
	public $rent;			
	public $unemployment;	//todo: this can be more complicated - can determine if growing or shrinking from data
	
	public $temperature;
	
	public $income;			//income object
	public $labour;			//list of all labour markets with # of employees
	
	//score
	public $crime_score;
	public $rent_score;
	public $unemployment_score;
	public $income_score;
	public $labour_score;
	public $culture_score;
	public $climate_score;
	
	public $total_score;
	
	//initialize the city
	function __construct()
	{
		$this->cultures = array();
		$this->crime_severity = 0;
		$this->crime_clearance = 0;
		$this->unemployment = 0;
		$this->rent = 0;
		$this->temperature = 0;
		$this->income = new Income();
		$this->labour = new Labour();
		
		$this->crime_score = 0;
		$this->rent_score = 0;
		$this->unemployment_score = 0;
		$this->income_score = 0;
		$this->labour_score = 0;
		$this->culture_score = 0;
		$this->climate_score = 0;
	}
}

class Culture
{
	public $name;
	public $population;
	public $percent_of_total;
	public $percent_of_minority;
}

class Income
{
	public $low;			//below $50k
	public $mid;			//between $50k and $100k
	public $high;			//above $100k
	public $total;			//total taxpayers
	public $average;		//average income
	public $total_income;	//total income across all taxpayers
	
	function __construct()
	{
		$this->low = 0;
		$this->mid = 0;
		$this->high = 0;
		$this->total = 0;
		$this->average = 0;
		$this->total_income = 0;
	}
}

class Labour
{
	public $province;	//province name
	
	//arrays of names and workers for each type of labour industry
	public $name;		//forestry, tech etc.
	public $workers;
	
	function __construct()
	{
		$this->name = array();
		$this->workers = array();
	}
}

/*
 * Returns an array of city objects from the city culture data files
 */
function parse_cities()
{
	$allcities = array();
	$culturaldata = "data/cultural-location/cities";
	$files = glob("$culturaldata/*.csv", GLOB_BRACE);
	
	//parse through each city data file looking for the particular "region" match
	foreach($files as $file)
	{
		if (($handle = fopen($file, "r")) !== FALSE) 
		{
			$cities = array();
			
			if (DEBUG == 1)
				echo "parsing: $file ...<br/>";
				
			$row = 0;
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
			{
				//4th row lists all cities in the file
				if($row == 3)
				{
					$num = count($data);
					//skip the first and last ones because always blank
					for ($c=1; $c < $num - 1; $c++)
					{
						$city = new City();
						$city->name = $data[$c];
						$city->temperature = get_avg_temp($city->name);
						array_push($cities,$city);
						
						if (DEBUG == 1)
							echo " '$data[$c]' ";
					}
					if (DEBUG == 1)
						echo "<br/>";
				}
				//total population data
				else if(strcmp($data[0], "Total population ") == 0)
				{
					$num = count($data);
					for ($c=1; $c < $num - 1; $c++)
						$cities[$c-1]->population = str_replace(',', '', $data[$c]);
				}
				//total visible minority population
				else if(strcmp($data[0], "Visible minority population") == 0)
				{
					$num = count($data);
					for ($c=1; $c < $num - 1; $c++)
						$cities[$c-1]->visible_pop = str_replace(',', '', $data[$c]);
				}				
				//the culture data falls between these rows
				else if(($row > 6) && ($row < 18))
				{
					$num = count($data);
					for ($c=1; $c < $num - 1; $c++)
					{
						$culture = new Culture();
						if(strstr($data[0], "Visible minority") != false)
							$culture->name = "Other";
						else
							$culture->name = $data[0];
						$culture->population = str_replace(',', '', $data[$c]);
						$culture->percent_of_total = $culture->population / $cities[$c-1]->population * 100;
						$culture->percent_of_minority = $culture->population / $cities[$c-1]->visible_pop * 100;
						array_push($cities[$c-1]->cultures, $culture);
					}
				}
				
				$row++;
			}
			
			//add all the cities we just found to the total array
			foreach($cities as $city)
				array_push($allcities, $city);

			fclose($handle);
		}
		else
			trigger_error("Can't open the city culture data");
	}
	return $allcities;
}

/*
 * parses a climate file for a city
 * and returns the average temperature
 */
function get_avg_temp($cityname)
{
	$climatedata = "data/climate/";
	
	$fcity = str_replace(' ', '', $cityname);
	$fcity = str_replace('\'', '', $fcity);
	$fcity = str_replace('.', '', $fcity);
	$fcity = str_replace('è', 'e', $fcity);
	$fcity = str_replace('é', 'e', $fcity);
	$fcity = strtolower($fcity);
	
	//kludges
	if((strstr($fcity,"montr") == true) && (strstr($fcity,"al")))
		$fcity = "montreal";
	elseif(strstr($fcity,"bec") == true)
		$fcity = "quebec";
	elseif(strstr($fcity,"trois") == true)
		$fcity = "trois-rivieres";
	elseif(strstr($fcity,"greatersudbury") == true)
		$fcity = "sudbury";
		
	$file = $climatedata.$fcity.".csv";
	if (($handle = fopen($file, "r")) !== FALSE) 
	{
		$row = 0;
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//this row has the city name in it
			if($row == 4)
			{
				$tempname = $data[0];
				if($tempname[0] == '*')
					$tempname = substr($data[0], 1);
			}
			else if(strstr($data[0], "Daily Average") == true)
			{
				$num = count($data);
				$avg_temp = $data[$num - 2];
				fclose($handle);
				return $avg_temp;
			}
			$row++;
		}
			
		fclose($handle);
	}
}

/*
 * parses a climate file for a city
 * and returns the average temperature
 */
function get_min_temp($cityname)
{
	$climatedata = "data/climate/";
	
	$fcity = str_replace(' ', '', $cityname);
	$fcity = str_replace('\'', '', $fcity);
	$fcity = str_replace('.', '', $fcity);
	$fcity = str_replace('è', 'e', $fcity);
	$fcity = str_replace('é', 'e', $fcity);
	$fcity = strtolower($fcity);
	
	//kludges
	if((strstr($fcity,"montr") == true) && (strstr($fcity,"al")))
		$fcity = "montreal";
	elseif(strstr($fcity,"bec") == true)
		$fcity = "quebec";
	elseif(strstr($fcity,"trois") == true)
		$fcity = "trois-rivieres";
	elseif(strstr($fcity,"greatersudbury") == true)
		$fcity = "sudbury";
		
	$file = $climatedata.$fcity.".csv";
	if (($handle = fopen($file, "r")) !== FALSE) 
	{
		$row = 0;
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//this row has the city name in it
			if($row == 4)
			{
				$tempname = $data[0];
				if($tempname[0] == '*')
					$tempname = substr($data[0], 1);
			}
			else if(strstr($data[0], "Daily Minimum") == true)
			{
				$num = count($data);
				$avg_temp = $data[$num - 2];
				fclose($handle);
				return $avg_temp;
			}
			$row++;
		}
			
		fclose($handle);
	}
}

/*
 * parses a climate file for a city
 * and returns the average temperature
 */
function get_max_temp($cityname)
{
	$climatedata = "data/climate/";
	
	$fcity = str_replace(' ', '', $cityname);
	$fcity = str_replace('\'', '', $fcity);
	$fcity = str_replace('.', '', $fcity);
	$fcity = str_replace('è', 'e', $fcity);
	$fcity = str_replace('é', 'e', $fcity);
	$fcity = strtolower($fcity);
	
	//kludges
	if((strstr($fcity,"montr") == true) && (strstr($fcity,"al")))
		$fcity = "montreal";
	elseif(strstr($fcity,"bec") == true)
		$fcity = "quebec";
	elseif(strstr($fcity,"trois") == true)
		$fcity = "trois-rivieres";
	elseif(strstr($fcity,"greatersudbury") == true)
		$fcity = "sudbury";
		
	$file = $climatedata.$fcity.".csv";
	if (($handle = fopen($file, "r")) !== FALSE) 
	{
		$row = 0;
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//this row has the city name in it
			if($row == 4)
			{
				$tempname = $data[0];
				if($tempname[0] == '*')
					$tempname = substr($data[0], 1);
			}
			else if(strstr($data[0], "Daily Maximum") == true)
			{
				$num = count($data);
				$avg_temp = $data[$num - 2];
				fclose($handle);
				return $avg_temp;
			}
			$row++;
		}
			
		fclose($handle);
	}
}

/*
 * Used to fill in the form on the main page with culture types
 * We can stop parsing the file after we go through one pass of the types
 */
function get_cultures()
{
	$culturaldata = "data/cultural-location/cities";
	$files = glob("$culturaldata/*.csv", GLOB_BRACE);
	
	//parse through each city data file looking for the particular "region" match
	foreach($files as $file)
	{
		if (($handle = fopen($file, "r")) !== FALSE) 
		{
			$row = 0;
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
			{
				if(($row > 6) && ($row < 18))
				{
					$culture = $data[0];
					?><option value="<?=$culture?>"><?=$culture?></option><?
				}
				
				$row++;
			}
			fclose($handle);
			break; //stop after first file
		}
	}
}

/*
 * Parses the labour by industries and 
 * returns an array of labour markets by province
 */
function parse_labour()
{
	$labours = array();
	$last_province = "Canada";
	$last_industry = "";
	$labour = false;
	
	$labourdata = "data/labour-by-industry.csv";
	if (($handle = fopen($labourdata, "r")) !== FALSE) 
	{
		$row = 0;
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 8)
				trigger_error("Error with format of labour data");
			else
			{
				$province = $data[1];
				$workers = $data[7];
				$industry = substr($data[4], 0, strpos($data[4], " (x 1,000)"));
				
				//new province to process
				if(($row > 0) && (strcmp($province, $last_province) != 0))
				{
					if($labour != false)
						array_push($labours, $labour);
						
					$labour = new Labour();
					$labour->province = $province;
					$labour->name = array();
					$labour->workers = array();
					array_push($labour->name, $industry);
					array_push($labour->workers, $workers);
					
					$last_province = $province;
					$last_industry = $industry;
					//echo $province."  ".$industry."  ".$workers."<br/>";
				}
				//check if we have a new industry to process
				else if(($row > 0) && ($labour != false) && (strcmp($workers, "x") != 0) && (strcmp($data[2], "Census metropolitan area and census agglomeration") == 0) && (strcmp($data[3], "Total employed, all classes of workers") == 0))
				{
					$found = false;
					
					//find the name in the list and update the worker total
					//todo: update this with a more efficient way than search the list each time
					for($c = 0; $c < count($labour->name); $c++)
					{
						$name = $labour->name[$c];
						if(strcmp($name, $industry) == 0)
						{
							$found = true;
							$labour->workers[$c] = $workers;
						}
					}
					
					if($found == false)
					{
						array_push($labour->name, $industry);
						array_push($labour->workers, $workers);
					}
				}
			}
			$row++;
		}
		fclose($handle);
		array_push($labours, $labour);	//push the final one to the array
	}
	else
		trigger_error("Can't open the labour data");
		
	return $labours;
}

/*
 * Used to fill in the form on the main page with labour areas
 * We can stop parsing the file after we go through one pass of the types
 */
function get_labour_areas()
{
	$labourdata = "data/labour-by-industry.csv";
	$last_province = "";
	$last_industry = "";
	
	if (($handle = fopen($labourdata, "r")) !== FALSE) 
	{
		$row = 0;
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			if($last_province == "")
				$last_province = $data[1];
			
			//echo $last_province."<br/>";	
			
			if((strcmp($data[2], "Census metropolitan area and census agglomeration") == 0) && (strcmp($data[3], "Total employed, all classes of workers") == 0))
			{
				$industry = substr($data[4], 0, strpos($data[4], " (x 1,000)"));
				
				//go until we repeat the second province
				if(strcmp($last_province, $data[1]) != 0)
					break;
					
				//print if we have a new industry and its not "all industries"
				if((strcmp($industry, "Total employed, all industries") != 0) && (strcmp($industry, $last_industry) != 0))
				{
					?><option value="<?=$industry?>"><?=$industry?></option><? echo "\n" ?><?
					$last_industry = $industry;
				}
			}
			$row++;
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the labour data");
}

/*
 * Given a list of city objects, fill in the crime data for the cities
 * from the crime data file
 */
function read_crime($cities)
{
	$crimedata = "data/crime.csv";
	if (($handle = fopen($crimedata, "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 7)
				trigger_error("Error with format of city crime data");
			else
			{
				if(strcmp($data[3], "Crime severity index") == 0)
				{
					//strip off the rest of the junk on the city name
					$name = strtok($data[1], ",");
					$city = match_city($cities, $name);
					if($city != false)
						if(strcmp($data[6], "..") != 0)
							$city->crime_severity = $data[6];
				}
				else if(strcmp($data[3], "Weighted clearance rate") == 0)
				{
					//strip off the rest of the junk on the city name
					$name = strtok($data[1], ",");
					$city = match_city($cities, $name);
					if($city != false)
						if(strcmp($data[6], "..") != 0)
							$city->crime_clearance = $data[6];
				}
			}
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the city crime data");
}

/*
 * Maps the city names to a province name, and adds the co-ordinates of
 * the city
 */
function read_province($cities)
{
	$provdata = "data/prov-city.csv";
	if (($handle = fopen($provdata, "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 4)
				trigger_error("Error with format of province/city mapping data");
			else
			{
				$city = match_city($cities, $data[0]);
				if($city != false)
				{
					$city->province = $data[1];
					$city->lat = $data[2];
					$city->long = $data[3];
				}
			}
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the province/city mapping data");
}

/*
 * Given a list of city objects, fill in the income data for the cities
 * from the crime data file
 * 
 * groups incomes into low,mid,high and records the avg income as well
 */
function read_income($cities)
{
	$incomedata = "data/income.csv";
	if (($handle = fopen($incomedata, "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 30)
				continue;
			else
			{
				if(strcmp(trim($data[4]), "CMA/RMR") == 0)
				{
					$city = match_city($cities, trim($data[5]));
					if($city != false)
					{
						for($c=12; $c<21; $c++)
							$city->income->low += $data[$c];
						
						for($c=21; $c<26; $c++)
							$city->income->mid += $data[$c];
						
						for($c=26; $c<29; $c++)
							$city->income->high += $data[$c];
							
						$city->income->total = $city->income->low + $city->income->mid + $city->income->high;
						$city->income->total_income = $data[11];
						$city->income->average = $data[29];
					}
				}
			}
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the city income data");
}

function read_unemployment($cities)
{
	$unemploymentdata = "data/unemployment.csv";
	if (($handle = fopen($unemploymentdata, "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 14)
				continue;
			else
			{
				//special case for fredericton and moncton
				if(strcmp($data[1], "FREDERICTON-MONCTON-SAINT JOHN") == 0)
				{
					$city = match_city($cities, "Moncton");
					if($city != false)
						$city->unemployment = $data[13];
					
					$city = match_city($cities, "Saint John");
					if($city != false)
						$city->unemployment = $data[13];
				}
				//special case for brantford and guelph
				else if(strcmp($data[1], "SOUTH CENTRAL ONTARIO") == 0)
				{
					$city = match_city($cities, "Guelph");
					if($city != false)
						$city->unemployment = $data[13];
					
					$city = match_city($cities, "Brantford");
					if($city != false)
						$city->unemployment = $data[13];
				}
				//special case for kingstong and peterborough
				else if(strcmp($data[1], "KINGSTON") == 0)
				{
					$city = match_city($cities, "Kingston");
					if($city != false)
						$city->unemployment = $data[13];
					
					$city = match_city($cities, "Peterborough");
					if($city != false)
						$city->unemployment = $data[13];
				}
				else if(strcmp($data[1], "MONTREAL") == 0)
				{
					$city = match_city($cities, "Montreal");
					if($city != false)
						$city->unemployment = $data[13];
				}
				else if(strcmp($data[1], "QUEBEC") == 0)
				{
					$city = match_city($cities, "Quebec");
					if($city != false)
						$city->unemployment = $data[13];
				}
				else if(strcmp($data[1], "TROIS-RIVI?RES") == 0)
				{
					$city = match_city($cities, "Trois-Rivieres");
					if($city != false)
						$city->unemployment = $data[13];
				}
				
				$city = match_city($cities, $data[1]);
				if($city != false)
					$city->unemployment = $data[13];
			}
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the city income data");
}

function read_rent($cities)
{
	$rentdata = "data/avg-rent.csv";
	if (($handle = fopen($rentdata, "r")) !== FALSE) 
	{
		while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
		{
			//start at oldest data, work up to newest
			$num = count($data);
				
			//make sure we don't go out of array bound
			if($num < 8)
				continue;
			else
			{
				//strip off the rest of the junk on the city name
				$name = strtok($data[1], ",");
				$city = match_city($cities, $name);
				if($city != false)
					if((strcmp($data[7], "..") != 0) && (strcmp($data[7], "F")))
					{
						$rent = $data[7];
						if($rent > 0)
							$city->rent = $data[7];
					}
				
			}
		}
		fclose($handle);
	}
	else
		trigger_error("Can't open the city rent data");
}

/*
 * Special function to try to retun a city
 * considering the kludginess of matching regions. For instance,
 * kitchener-waterloo may also be waterloo region, kitchener etc. This
 * function tries to deal with that and always return the correct city
 */
function match_city($cities, $name)
{
	if(sizeof($cities) > 0)
	{
		foreach($cities as $city)
		{
			if(strcmp($name, $city->name) == 0)
				return $city;
			
			if(strcmp($name, strtoupper($city->name)) == 0)
				return $city;
				
			//special case: Abbotsford
			else if((strcmp($name, "Abbotsford") == 0) || (strcmp($name, strtoupper("Abbotsford")) == 0))
			{
				if(strcmp($city->name, "Abbotsford-Mission") == 0)
					return $city;
			}
			//special case: Sudbury
			else if((strcmp($name, "Greater Sudbury") == 0) || (strcmp($name, "SUDBURY") == 0))
			{
				if(strcmp($city->name, "Greater Sudbury/Grand Sudbury") == 0)
					return $city;
			}
			//special case: KW
			else if((strcmp($name, "Waterloo Region (Kitchener)") == 0) || (strcmp($name, "Kitchener") == 0) || (strcmp($name, "KITCHENER") == 0))
			{
				if(strcmp($city->name, "Kitchener-Cambridge-Waterloo") == 0)
					return $city;
			}
			//special case: Niagara
			else if((strcmp($name, "Niagara Region (St. Catharines)") == 0) || (strcmp($name, "ST. CATHARINES") == 0))
			{
				if(strcmp($city->name, "St. Catharines-Niagara") == 0)
					return $city;
			}
			//special case: Oshawa
			else if((strcmp($name, "Durham Region (Oshawa/Whitby/Ajax)") == 0) || (strcmp($name, strtoupper("Durham Region (Oshawa/Whitby/Ajax)")) == 0))
			{
				if(strcmp($city->name, "Oshawa") == 0)
					return $city;
			}
			//special case: Peterborough
			else if((strcmp($name, "Peterborough-Lakefield") == 0) || (strcmp($name, strtoupper("Peterborough-Lakefield")) == 0))
			{
				if(strcmp($city->name, "Peterborough") == 0)
					return $city;
			}
			//special case: Ottawa
			else if((strcmp($name, "Ottawa") == 0) || (strcmp($name, strtoupper("Ottawa")) == 0))
			{
				if(strcmp($city->name, "Ottawa-Gatineau") == 0)
					return $city;
			}
			//special case: Moncton
			else if((strcmp($name, "Codiac Regional") == 0) || (strcmp($name, strtoupper("Codiac Regional")) == 0))
			{
				if(strcmp($city->name, "Moncton") == 0)
					return $city;
			}
			//special case: Quebec (problem with accent)
			else if(strcmp($name, "Quebec") == 0)
			{
				if((strstr($city->name, "Qu") == true) && (strstr($city->name, "bec") == true))
					return $city;
			}
			//special case: Trois-Rivieres (problem with accent)
			else if(strcmp($name, "Trois-Rivieres") == 0)
			{
				if((strstr($city->name, "Trois-Rivi") == true) && (strstr($city->name, "res") == true))
					return $city;
			}
			//special case: Montreal (problem with accent)
			else if(strcmp($name, "Montreal") == 0)
			{
				if((strstr($city->name, "Montr") == true) && (strstr($city->name, "al") == true))
					return $city;
			}
			//special case: kelowna: SOUTHERN INTERIOR BRITISH COLUMBIA
			else if(strcmp($name, "SOUTHERN INTERIOR BRITISH COLUMBIA") == 0)
			{
				if(strcmp($city->name, "Kelowna") == 0)
					return $city;
			}
			//special case: barrie: CENTRAL ONTARIO
			else if(strcmp($name, "CENTRAL ONTARIO") == 0)
			{
				if(strcmp($city->name, "Barrie") == 0)
					return $city;
			}
			//special case: Saguenay: CHICOUTIMI-JONQUI?RE
			else if(strcmp($name, "CHICOUTIMI-JONQUI?RE") == 0)
			{
				if(strcmp($city->name, "Saguenay") == 0)
					return $city;
			}
		}
	}
	
	return false;
}

/*
 * This function figures out which labour market data goes with which city
 */
function map_city_to_labour($cities, $labours)
{
	foreach($cities as $city)
	{
		foreach($labours as $labour)
		{
			if(strcmp($city->province, $labour->province) == 0)
			{
				$city->labour = $labour;
				break;
			}
		}
	}
}

/*
 * Given an array of cities, print them
 */
function print_cities($cities)
{
	echo "Number of cities: ".sizeof($cities)."<br/>";
	if(sizeof($cities) > 0)
	{
		foreach($cities as $city)
		{
			echo "  CITY: $city->name";
			echo "  PROVINCE: $city->province";
			echo "  LONG: $city->long";
			echo "  LAT: $city->lat";
			echo "  POP: $city->population";
			echo "  VISIBLE POP: $city->visible_pop";
			print_cultures($city->cultures);
			echo "  C_SEVERITY: $city->crime_severity";
			echo "  C_CLEARANCE: $city->crime_clearance";
			echo "  UNEMPLOYMENT: $city->unemployment";
			echo "  RENT: $city->rent";
			echo "  TEMP: $city->temperature<br/>";
			print_income($city->income);
			print_labour($city->labour);
			echo "</br>";
		}
	}
}

function print_cultures($cultures)
{
	echo "<br/>Number of cultures: ".sizeof($cultures)."<br/>";
	
	if(sizeof($cultures) > 0)
	{
		foreach($cultures as $culture)
		{
			echo "  CULTURE: $culture->name";
			echo "  POP: $culture->population";
			echo "  %TOTAL: $culture->percent_of_total";
			echo "  %MINORITY: $culture->percent_of_minority";
			echo "<br/>";
		}
	}
}

function print_income($income)
{
	if($income)
	{
		echo "  INCOME - LOW: $income->low";
		echo "  MID: $income->mid";
		echo "  HIGH: $income->high";
		echo "  TOTAL: $income->total";
		echo "  AVG: \$$income->average";
		echo "  TOTAL INCOME: \$$income->total_income";
		echo "<br/>";
	}
}

function print_labour($labour)
{
	if($labour)
	{
		echo "  LABOUR PROVINCE: $labour->province <br/>  ";
		for($c = 0; $c < count($labour->name); $c++)
		{
			$name = $labour->name[$c];
			$workers = $labour->workers[$c];
			echo "  NAME: $name  WORKERS: $workers  ";
		}
		echo "<br/>";
	}
}

?>
