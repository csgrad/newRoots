<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Electric Sheep: Jason Ernst and Carlos Saavedra">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">
    <title>newRoots by Electric Sheep</title>
    <!-- Bootstrap core CSS -->
    <link href="styles/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="styles/custom.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="images/newRootsLogo.png"/></a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="form.php">Find a Match</a></li>
            <li><a href="https://twitter.com/2ElectricSheep">Electric Sheep Twitter Page</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
    
        <div class="jumbotron">
      <div class="container">
      
<p><img src="images/leafCut.png"/></p>
        <p><a class="btn btn-lg btn-success" href="form.php" role="button">Find a Match</a></p>
      </div>
    </div>

    <!-- Begin page content -->
    <div class="container">
      <div class="page-header">
        <h2>A Match for Success</h2>
      </div>
      <p class="lead">By using open data sets provided by the Government of Canada, newRoots matches new Canadians with cities that will give them the greatest opportunity to maximize their potential, be successful, and be productive citizens of Canada.</p>
      
      <div class="page-header">
        <h2>Data Sets Used</h2>
      </div>
      <p class="lead">By using data sets in <b>income</b>, <b>visible minority populations</b>, <b>crime rates</b>, <b>housing opportunities</b>, <b>climate</b>, <b>unemployment rates</b>, and <b>labour industries</b>, newRoots is able to rank each major city in Canada for analysis.</p>
      
      <div class="page-header">
        <h2>Future Opportunities</h2>
      </div>
      <p class="lead">While focused on new Canadians, newRoots can be used in the real estate market to offer more economic and social data for those looking to purchase or rent a new home. The Government of Canada and provinces could also use this tool to determine how resources should be allocated. Finally, the tool could also be used when job searching in a different city. We have just scratched the surface on what newRoots can do for Canada.</p>
      
      
    </div>

    <div id="footer">
      <div class="container">
      
        <p class="text-muted"><img src="images/newRootsLogo.png"/><br />&copy; Copyright Electric Sheep 2014. All Rights Reserved.</p>
      </div>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
    <script src="styles/bootstrap.min.js"></script>
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3483823-6', 'jasonernst.com');
  ga('send', 'pageview');

</script>
        
        
  </body>
</html>
