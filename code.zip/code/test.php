<?
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once("score.php");

$cities = parse_cities();
read_province($cities);
read_crime($cities);
read_income($cities);
read_unemployment($cities);
read_rent($cities);
$labours = parse_labour();
map_city_to_labour($cities, $labours);
print_cities($cities);

?>
