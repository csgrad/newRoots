<?
	require_once("score.php");

	$neutral_weight = 1/5;
	$important_weight = 1/2;
	$very_important_weight = 1;

	$income = "";
	$incomeweight = 0;
	$industry = "";
	$industryweight = 0;
	$culture = "";
	$cultureweight = 0;
	$climate = "";
	$climateweight = 0;
	$housingweight = 0;
	$crimeweight = 0;

	if(isset($_POST['income']))
		$income = $_POST['income'];
	
	if(isset($_POST['industry']))
		$industry = $_POST['industry'];
	if(isset($_POST['climate']))
		$climate = $_POST['climate'];
	if(isset($_POST['culture']))
		$culture = $_POST['culture'];

	if(isset($_POST['optionsRadiosIncome']))
	{
		if(strcmp($_POST['optionsRadiosIncome'], "Neutral") == 0)
			$incomeweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosIncome'], "Important") == 0)
			$incomeweight = $important_weight;
		else
			$incomeweight = $very_important_weight;
	}
	
	if(isset($_POST['optionsRadiosJob']))
	{
		if(strcmp($_POST['optionsRadiosJob'], "Neutral") == 0)
			$industryweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosJob'], "Important") == 0)
			$industryweight = $important_weight;
		else
			$industryweight = $very_important_weight;
	}
	
	if(isset($_POST['optionsRadiosClimate']))
	{
		if(strcmp($_POST['optionsRadiosClimate'], "Neutral") == 0)
			$climateweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosClimate'], "Important") == 0)
			$climateweight = $important_weight;
		else
			$climateweight = $very_important_weight;
	}
	
	if(isset($_POST['optionsRadiosCulture']))
	{
		if(strcmp($_POST['optionsRadiosCulture'], "Neutral") == 0)
			$cultureweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosCulture'], "Important") == 0)
			$cultureweight = $important_weight;
		else
			$cultureweight = $very_important_weight;
	}
	
	if(isset($_POST['optionsRadiosHousing']))
	{
		if(strcmp($_POST['optionsRadiosHousing'], "Neutral") == 0)
			$housingweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosHousing'], "Important") == 0)
			$housingweight = $important_weight;
		else
			$housingweight = $very_important_weight;
	}
	
	if(isset($_POST['optionsRadiosCrime']))
	{
		if(strcmp($_POST['optionsRadiosCrime'], "Neutral") == 0)
			$crimeweight = $neutral_weight;
		else if(strcmp($_POST['optionsRadiosCrime'], "Important") == 0)
			$crimeweight = $important_weight;
		else
			$crimeweight = $very_important_weight;
	}

$cities = parse_cities();
read_province($cities);		
read_crime($cities);
read_income($cities);
read_unemployment($cities);
read_rent($cities);

//these take significantly longer to compute because the labour file is huge
$labours = parse_labour();
map_city_to_labour($cities, $labours);

$lowest_crime = 999999999;
$highest_crime = 0;
$lowest_income = 999999999;
$highest_income = 0;
$lowest_unemployment = 999999999;
$highest_unemployment = 0;
$lowest_rent = 999999999;
$highest_rent = 0;
$lowest_culture = 999999999;
$highest_culture = 0;
$lowest_labour = 999999999;
$highest_labour = 0;
$lowest_temp_score = 999999999;
$highest_temp_score = 0;
foreach($cities as $city)
{	
	//crime score
	if($city->crime_severity < $lowest_crime)
		$lowest_crime = $city->crime_severity;
	if($city->crime_severity > $highest_crime)
		$highest_crime = $city->crime_severity;
	
	//income score
	if($city->income->total == 0)
		$ratio = 0;
	else if(strcmp($income, "$10,000 - $50,000") == 0)
	{
		$ratio = $city->income->low / $city->income->total;
	}
	else if(strcmp($income, "$50,000 - $100,000") == 0)
	{
		$ratio = $city->income->mid / $city->income->total;	
	}
	else if(strcmp($income, "Over $100,000") == 0)
	{
		$ratio = $city->income->high / $city->income->total;
	}
	else
		$ratio = 0;
		
	if($ratio < $lowest_income)
		$lowest_income = $ratio;
	if($ratio > $highest_income)
		$highest_income = $ratio;
	
	//unemployment score
	if($city->unemployment < $lowest_unemployment)
		$lowest_unemployment = $city->unemployment;
	if($city->unemployment > $highest_unemployment)
		$highest_unemployment = $city->unemployment;
		
	//rent score
	if($city->rent < $lowest_rent)
		$lowest_rent = $city->rent;
	if($city->rent > $highest_rent)
		$highest_rent = $city->rent;
		
	//culture score
	foreach($city->cultures as $cul)
	{
		//check for matching culture
		if(strcmp($culture, $cul->name) == 0)
		{
			if($cul->percent_of_total < $lowest_culture)
				$lowest_culture = $cul->percent_of_total;
			if($cul->percent_of_total > $highest_culture)
				$highest_culture = $cul->percent_of_total;
				
			break;
		}
	}
	
	//labour score
	$count = 0;
	foreach($city->labour->name as $ind)
	{
		if(strcmp($ind, $industry) == 0)
		{
			$labour = $city->labour->workers[$count];
			$labour_ratio = $labour / $city->population;
			if($labour_ratio < $lowest_labour)
				$lowest_labour = $labour_ratio;
			if($labour_ratio > $highest_labour)
				$highest_labour = $labour_ratio;
			
			break;
		}
		$count++;
	}
	
	//climate score
	if($city->temperature > $highest_temp_score)
		$highest_temp_score = $city->temperature;
	if($city->temperature < $lowest_temp_score) 
		$lowest_temp_score = $city->temperature;
}

//top three scores
$first_place = 0; $first_index = -1;
$second_place = 0; $second_index = -1;
$third_place = 0; $third_index = -1;
$fourth_place = 0; $fourth_index = -1;
$fifth_place = 0; $fifth_index = -1;

$index = 0;
foreach($cities as $city)
{
	//crime score
	$city->crime_score = (1-(($city->crime_severity - $lowest_crime) / ($highest_crime - $lowest_crime)))*100;
	
	//income score
	if($city->income->total == 0)
		$ratio = 0;
	else if(strcmp($income, "$10,000 - $50,000") == 0)
		$ratio = $city->income->low / $city->income->total;
	else if(strcmp($income, "$50,000 - $100,000") == 0)
		$ratio = $city->income->mid / $city->income->total;
	else
		$ratio = $city->income->high / $city->income->total;
	
	if(($ratio == 0) || (($highest_income == 0) && ($lowest_income == 0)))
		$city->income_score = 0;
	else
		$city->income_score = (($ratio - $lowest_income) / ($highest_income - $lowest_income)) * 100;
	
	//unemployment score
	$city->unemployment_score = (1-(($city->unemployment - $lowest_unemployment) / ($highest_unemployment - $lowest_unemployment))) * 100;
	
	//rent score
	$city->rent_score = (1-(($city->rent - $lowest_rent) / ($highest_rent - $lowest_rent))) * 100;
	
	//culture score
	foreach($city->cultures as $cul)
	{
		//check for matching culture
		if(strcmp($culture, $cul->name) == 0)
		{
			$city->culture_score = (($cul->percent_of_total - $lowest_culture) / ($highest_culture - $lowest_culture)) * 100;
			//echo "CITY: $city->name CUL: $cul->percent_of_total SCORE: $city->culture_score <br/>";
			break;
		}
	}
		
	//labour score
	$count = 0;
	foreach($city->labour->name as $ind)
	{
		if(strcmp($ind, $industry) == 0)
		{
			$labour = $city->labour->workers[$count];
			$labour_ratio = $labour / $city->population;
						
			$city->labour_score = (($labour_ratio - $lowest_labour) / ($highest_labour - $lowest_labour)) * 100;
			//echo "CITY: $city->name LAB: $labour_ratio SCORE: $city->labour_score <br/>";
			break;
		}
		$count++;
	}
	
	//climate score
	if(strcmp($climate, "Warm") == 0)
		$city->climate_score = (1-(($highest_temp_score - $city->temperature) / ($highest_temp_score - $lowest_temp_score))) * 100;
	else if(strcmp($climate, "Mild") == 0)
	{
		$avg_temp = ($lowest_temp_score + $highest_temp_score) / 2;
		$city->climate_score = (1-((abs($city->temperature-$avg_temp)) / ($avg_temp))) * 100;
	}
	else if(strcmp($climate, "Cold") == 0)
		$city->climate_score = (1-((abs($city->temperature-$lowest_temp_score)) / ($highest_temp_score - $lowest_temp_score))) * 100;
	else
		$city->climate_score = 0;
	
	$city->total_score = ($cultureweight*$city->culture_score) + ($crimeweight*$city->crime_score) + ($incomeweight*$city->income_score) + ($industryweight*$city->unemployment_score) + ($housingweight*$city->rent_score) + ($industryweight*$city->labour_score) + ($climateweight*$city->climate_score);
	$city->total_score = $city->total_score / ($cultureweight + $crimeweight + $incomeweight + $industryweight + $housingweight + $industryweight + $climateweight);
		
	if($city->total_score > $first_place)
	{
		$fifth_index = $fourth_index;
		$fourth_index = $third_index;
		$third_index = $second_index;
		$second_index = $first_index;
		$first_index = $index;
		
		$fifth_place = $fourth_place;
		$fourth_place = $third_place;
		$third_place = $second_place;
		$second_place = $first_place;
		$first_place = $city->total_score;
	}
	else if($city->total_score > $second_place)
	{
		$fifth_index = $fourth_index;
		$fourth_index = $third_index;
		$third_index = $second_index;
		$second_index = $index;
		
		$fifth_place = $fourth_place;
		$fourth_place = $third_place;
		$third_place = $second_place;
		$second_place = $city->total_score;
	}
	else if($city->total_score > $third_place)
	{
		$fifth_index = $fourth_index;
		$fourth_index = $third_index;
		$third_index = $index;
		
		$fifth_place = $fourth_place;
		$fourth_place = $fifth_place;
		$third_place = $city->total_score;
	}
	else if($city->total_score > $fourth_place)
	{
		$fifth_index = $fourth_index;
		$fourth_index = $index;
		
		$fifth_place = $fourth_place;
		$fourth_place = $city->total_score;
	}
	else if($city->total_score > $fifth_place)
	{
		$fifth_index = $index;
		$fifth_place = $city->total_score;
	}
	
	$index++;
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Electric Sheep: Jason Ernst and Carlos Saavedra">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">
    <title>newRoots by Electric Sheep</title>
    <!-- Bootstrap core CSS -->
    <link href="styles/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="styles/custom.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAA3zIl-FzUavwu7J_ddxMR7kJdCMOywp0&sensor=false">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = { center: new google.maps.LatLng(52.0, -97), zoom: 3, draggable: false };
        var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
        
		<? $distance = $cities[$first_index]->total_score; ?>
		var markerPos1 = new google.maps.LatLng(<?=$cities[$first_index]->lat?>,<?=$cities[$first_index]->long?>);
		var destmarker1 = new google.maps.Marker({position: markerPos1,map: map});
		var circleOptions1 = { strokeColor: '#FF0000', strokeOpacity: 0.8, strokeWeight: 2, fillColor: '#FF0000', fillOpacity: 0.15, map: map, center: markerPos1, radius: <?=$distance?> * 1000 };
		var circle1 = new google.maps.Circle(circleOptions1);
		
		<? $distance = $cities[$second_index]->total_score; ?>
		var markerPos2 = new google.maps.LatLng(<?=$cities[$second_index]->lat?>,<?=$cities[$second_index]->long?>);
		var destmarker2 = new google.maps.Marker({position: markerPos2,map: map});
		var circleOptions2 = { strokeColor: '#FF0000', strokeOpacity: 0.8, strokeWeight: 2, fillColor: '#FF0000', fillOpacity: 0.15, map: map, center: markerPos2, radius: <?=$distance?> * 1000 };
		var circle2 = new google.maps.Circle(circleOptions2);     
		
		<? $distance = $cities[$third_index]->total_score; ?>
		var markerPos3 = new google.maps.LatLng(<?=$cities[$third_index]->lat?>,<?=$cities[$third_index]->long?>);
		var destmarker3 = new google.maps.Marker({position: markerPos3,map: map});
		var circleOptions3 = { strokeColor: '#FF0000', strokeOpacity: 0.8, strokeWeight: 2, fillColor: '#FF0000', fillOpacity: 0.15, map: map, center: markerPos3, radius: <?=$distance?> * 1000 };
		var circle3 = new google.maps.Circle(circleOptions3);     
		
		<? $distance = $cities[$fourth_index]->total_score; ?>
		var markerPos4 = new google.maps.LatLng(<?=$cities[$fourth_index]->lat?>,<?=$cities[$fourth_index]->long?>);
		var destmarker4 = new google.maps.Marker({position: markerPos4,map: map});
		var circleOptions4 = { strokeColor: '#FF0000', strokeOpacity: 0.8, strokeWeight: 2, fillColor: '#FF0000', fillOpacity: 0.15, map: map, center: markerPos4, radius: <?=$distance?> * 1000 };
		var circle4 = new google.maps.Circle(circleOptions4);     
		
		<? $distance = $cities[$fifth_index]->total_score; ?>
		var markerPos5 = new google.maps.LatLng(<?=$cities[$fifth_index]->lat?>,<?=$cities[$fifth_index]->long?>);
		var destmarker5 = new google.maps.Marker({position: markerPos5,map: map});
		var circleOptions5 = { strokeColor: '#FF0000', strokeOpacity: 0.8, strokeWeight: 2, fillColor: '#FF0000', fillOpacity: 0.15, map: map, center: markerPos5, radius: <?=$distance?> * 1000 };
		var circle5 = new google.maps.Circle(circleOptions5);           
		
      }
      
      //
      function selectCity(cityName, score, crime_score, income_score, unemployment_score, housing_score, labour_score, climate_score, culture_score)
      {
		  //alert(score+" "+crime_score+" "+income_score+" "+unemployment_score+" "+housing_score+" "+labour_score+" "+climate_score);
		  document.getElementById('city').value = cityName;
		  document.getElementById('score').value = score;
		  document.getElementById('income_score').value = income_score;
		  document.getElementById('crime_score').value = crime_score;
		  document.getElementById('unemployment_score').value = unemployment_score;
		  document.getElementById('housing_score').value = housing_score;
		  document.getElementById('labour_score').value = labour_score;
		  document.getElementById('climate_score').value = climate_score;
		  document.getElementById('culture_score').value = culture_score;
		  document.getElementById('form').submit();
	  }
	  
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>

<body>

    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="images/newRootsLogo.png"/></a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="form.php">Find a Match</a></li>
            <li><a href="https://twitter.com/2ElectricSheep">Electric Sheep Twitter Page</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>

    <!-- Begin page content -->
    <div class="container">
    
    <div class="btn-group btn-group-justified">
  <div class="btn-group">
    <button type="button" class="btn btn-default" onClick="window.location.href='form.php';"><span class="glyphicon glyphicon-search"></span>Search</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default active"><span class="glyphicon glyphicon-list"></span>List</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default" onClick="window.location.href='results.php';"><span class="glyphicon glyphicon-stats"></span>Results</button>
  </div>
</div>
    
    
    <div class="map" id="map-canvas">
    </div>

	<form action="results.php" method="POST" id="form">

    <div class="row">
    <a href="#" onClick='selectCity("<?=htmlspecialchars($cities[$first_index]->name, ENT_QUOTES)?>", "<?=round($cities[$first_index]->total_score)?>", "<?=round($cities[$first_index]->crime_score)?>", "<?=round($cities[$first_index]->income_score)?>", "<?=round($cities[$first_index]->unemployment_score)?>", "<?=round($cities[$first_index]->rent_score)?>", "<?=round($cities[$first_index]->labour_score)?>", "<?=round($cities[$first_index]->climate_score)?>", "<?=round($cities[$first_index]->culture_score)?>");'>
    	<div class="col">
        <p class="city"><?=$cities[$first_index]->name?><br /><span><?=$cities[$first_index]->province?></span> <span class="glyphicon glyphicon-circle-arrow-right"></span></p> 
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=round($cities[$first_index]->total_score);?>%</span><br />newRoots Compatibility</p>
        </div>
    </a>
    </div>

    <div class="row">
    <a href="#" onClick='selectCity("<?=htmlspecialchars($cities[$second_index]->name, ENT_QUOTES)?>", "<?=round($cities[$second_index]->total_score)?>", "<?=round($cities[$second_index]->crime_score)?>", "<?=round($cities[$second_index]->income_score)?>", "<?=round($cities[$second_index]->unemployment_score)?>", "<?=round($cities[$second_index]->rent_score)?>", "<?=round($cities[$second_index]->labour_score)?>", "<?=round($cities[$second_index]->climate_score)?>", "<?=round($cities[$second_index]->culture_score)?>");'>
    	<div class="col">
        <p class="city"><?=$cities[$second_index]->name?><br /><span><?=$cities[$second_index]->province?></span> <span class="glyphicon glyphicon-circle-arrow-right"></span></p> 
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=round($cities[$second_index]->total_score);?>%</span><br />newRoots Compatibility</p>
        </div>
    </a>
    </div>

    <div class="row">
    <a href="#" onClick='selectCity("<?=htmlspecialchars($cities[$third_index]->name, ENT_QUOTES)?>", "<?=round($cities[$third_index]->total_score)?>", "<?=round($cities[$third_index]->crime_score)?>", "<?=round($cities[$third_index]->income_score)?>", "<?=round($cities[$third_index]->unemployment_score)?>", "<?=round($cities[$third_index]->rent_score)?>", "<?=round($cities[$third_index]->labour_score)?>", "<?=round($cities[$third_index]->climate_score)?>", "<?=round($cities[$third_index]->culture_score)?>");'>
    	<div class="col">
        <p class="city"><?=$cities[$third_index]->name?><br /><span><?=$cities[$third_index]->province?></span> <span class="glyphicon glyphicon-circle-arrow-right"></span></p> 
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=round($cities[$third_index]->total_score);?>%</span><br />newRoots Compatibility</p>
        </div>
    </a>
    </div>

    <div class="row">
    <a href="#" onClick='selectCity("<?=htmlspecialchars($cities[$fourth_index]->name, ENT_QUOTES)?>", "<?=round($cities[$fourth_index]->total_score)?>", "<?=round($cities[$fourth_index]->crime_score)?>", "<?=round($cities[$fourth_index]->income_score)?>", "<?=round($cities[$fourth_index]->unemployment_score)?>", "<?=round($cities[$fourth_index]->rent_score)?>", "<?=round($cities[$fourth_index]->labour_score)?>", "<?=round($cities[$fourth_index]->climate_score)?>", "<?=round($cities[$fourth_index]->culture_score)?>");'>
    	<div class="col">
        <p class="city"><?=$cities[$fourth_index]->name?><br /><span><?=$cities[$fourth_index]->province?></span> <span class="glyphicon glyphicon-circle-arrow-right"></span></p> 
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=round($cities[$fourth_index]->total_score);?>%</span><br />newRoots Compatibility</p>
        </div>
    </a>
    </div>
    
    <div class="row">
    <a href="#" onClick='selectCity("<?=htmlspecialchars($cities[$fifth_index]->name, ENT_QUOTES)?>", "<?=round($cities[$fifth_index]->total_score)?>", "<?=round($cities[$fifth_index]->crime_score)?>", "<?=round($cities[$fifth_index]->income_score)?>", "<?=round($cities[$fifth_index]->unemployment_score)?>", "<?=round($cities[$fifth_index]->rent_score)?>", "<?=round($cities[$fifth_index]->labour_score)?>", "<?=round($cities[$fifth_index]->climate_score)?>", "<?=round($cities[$fifth_index]->culture_score)?>");'>
    	<div class="col">
        <p class="city"><?=$cities[$fifth_index]->name?><br /><span><?=$cities[$fifth_index]->province?></span> <span class="glyphicon glyphicon-circle-arrow-right"></span></p> 
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=round($cities[$fifth_index]->total_score);?>%</span><br />newRoots Compatibility</p>
        </div>
    </a>
    </div>            
		<input type="hidden" name="city" id="city" value="0"/>
		<input type="hidden" name="score" id="score" value="0"/>
		<input type="hidden" name="crime_score" id="crime_score" value="0"/>
		<input type="hidden" name="income_score" id="income_score" value="0"/>
		<input type="hidden" name="unemployment_score" id="unemployment_score" value="0"/>
		<input type="hidden" name="housing_score" id="housing_score" value="0"/>
		<input type="hidden" name="labour_score" id="labour_score" value="0"/>
		<input type="hidden" name="climate_score" id="climate_score" value="0"/>
		<input type="hidden" name="culture_score" id="culture_score" value="0"/>
	</form>

    
      <div class="page-header">
        <h2>How is this ranked?</h2>
      </div>
      <p class="lead">Based on data sets provided by the Government of Canada and the information you submitted, we weight each category based on importance and compare that to city averages in each category to determine your newRoots compatibility score.</p>
      
      
      
    </div>

    <div id="footer">
      <div class="container">
      
        <p class="text-muted"><img src="images/newRootsLogo.png"/><br />&copy; Copyright Electric Sheep 2014. All Rights Reserved.</p>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
    <script src="styles/bootstrap.min.js"></script>
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3483823-6', 'jasonernst.com');
  ga('send', 'pageview');

</script>
    
  </body>
</html>
