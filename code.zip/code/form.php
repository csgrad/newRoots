<? require_once("score.php"); ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Electric Sheep: Jason Ernst and Carlos Saavedra">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">
    <title>newRoots by Electric Sheep</title>
    <!-- Bootstrap core CSS -->
    <link href="styles/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="styles/custom.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
       
  </head>

  <body>

    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="images/newRootsLogo.png"/></a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="form.php">Find a Match</a></li>
            <li><a href="https://twitter.com/2ElectricSheep">Electric Sheep Twitter Page</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>

    <!-- Begin page content -->
    <div class="container">
    
    <div class="btn-group btn-group-justified">
  <div class="btn-group">
    <button type="button" class="btn btn-default active"><span class="glyphicon glyphicon-search"></span>Search</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default" disabled="disabled"><span class="glyphicon glyphicon-list"></span>List</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default" disabled="disabled"><span class="glyphicon glyphicon-stats"></span>Results</button>
  </div>
</div>
    
      <div class="page-header">
        <h2>Search for a Match.</h2>
      </div>
      <p class="lead">Fill in the following fields so that we can best match you with a city that will allow you to prosper as a proud Canadian citizen.</p>
      
      <p>
      
      <form role="form" action="selection_handler.php" method="POST">
    
    <div class="form-group">
      <label><span class="glyphicon glyphicon-usd"></span>Expected Household Income:</label>
      <select class="form-control" name="income">
		<option value="" selected="selected">Choose</option>
		<option value="$10,000 - $50,000">$10,000 - $50,000 / year</option>
		<option value="$50,000 - $100,000">$50,000 - $100,000 / year</option>
		<option value="Over $100,000">Over $100,000 / year</option>
      </select>
      
      <div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosIncome" id="incomeneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosIncome" id="incomeimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosIncome" id="incomeveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span>
			</label>
		</div>   
    </div>
    
	<div class="form-group">
		<label><span class="glyphicon glyphicon-briefcase"></span>Preferred Job Industry:</label>
		<select class="form-control" name="industry">
			<option value="" selected="selected">Choose</option>
			<? get_labour_areas(); ?>
		</select>     
		<div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosJob" id="labourneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosJob" id="labourimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosJob" id="labourveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span>
			</label>
		</div>   
     </div>
    
	<div class="form-group">
      <label><span class="glyphicon glyphicon-cloud"></span>Preferred Climate:</label>
      <select class="form-control" name="climate">
		<option value="" selected="selected">Choose</option>
		<option value="Warm">Warm</option>
		<option value="Mild">Mild</option>
		<option value="Cold">Cold</option>
      </select>
      
		<div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosClimate" id="climateneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosClimate" id="climateimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosClimate" id="climateveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
		</div>   
    </div>
    
    
    <div class="form-group">
      <label><span class="glyphicon glyphicon-user"></span>Preferred Community Group:</label>
      <select class="form-control" name="culture">
      <option value="" selected="selected">Choose</option>
		<? get_cultures(); ?>
      </select>
      
		<div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCulture" id="cultureneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCulture" id="cultureimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCulture" id="cultureveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
			</div>   
		</div>
    
    
    <div class="form-group">
      <label><span class="glyphicon glyphicon-home"></span>Affordable Housing:</label>
      <!--
      <select class="form-control">
		<option value="" selected="selected">Choose</option>
		<option value="Purchase">Purchase Household</option>
		<option value="Rent">Rent</option>
      </select>
      -->
		<div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHousing" id="housingneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHousing" id="housingimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHousing" id="housingveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
		</div> 
    </div>
    
    <!-- 
	<div class="form-group">
      <label><img src="images/healthIcon.png"/>Health of Residents:</label>
		<div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHealth" id="optionsRadios1" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHealth" id="optionsRadios" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosHealth" id="optionsRadios2" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
			</div> 
		</div>
    -->
    
	<div class="form-group">
      <label><img src="images/sirenIcon.png"/></span>City Crime Rate:</label>
      <div class="centered">
			<label class="radio-inline2"><b>How Important?</b></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCrime" id="crimeneutral" value="Neutral" checked><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCrime" id="crimeimportant" value="Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
				<label class="radio-inline"><input type="radio" name="optionsRadiosCrime" id="crimeveryimportant" value="Very Important"><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span><span class="glyphicon glyphicon-thumbs-up"></span></label>
	  </div>   
	</div>    
	
	<div class="alert alert-warning"><center>Due to the number of records being processed across many data sets, please expect a wait of up to ten or fifteen seconds for your results to show.</center></div>
	
    <button type="submit" class="btn btn-primary btn-block">Find a Match</button>
    
</form>
      
      
      
      </p>
      
      
    </div>

    <div id="footer">
      <div class="container">
      
        <p class="text-muted"><img src="images/newRootsLogo.png"/><br />&copy; Copyright Electric Sheep 2014. All Rights Reserved.</p>
      </div>
    </div>

	<div id="preload" style="display:none;">
		
	</div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
    <script src="styles/bootstrap.min.js"></script>
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3483823-6', 'jasonernst.com');
  ga('send', 'pageview');

</script>    
        
  </body>
</html>
