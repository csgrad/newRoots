<?
require_once("score.php");

$cityname = "No City Selected";
$score = 0;
$crime_score = 0;
$income_score = 0;
$unemployment_score = 0;
$housing_score = 0;
$labour_score = 0;
$climate_score = 0;
$culture_score = 0;

if(isset($_POST['city']))
	$cityname = $_POST['city'];
if(isset($_POST['score']))
	$score = $_POST['score'];
if(isset($_POST['crime_score']))
	$crime_score = $_POST['crime_score'];
if(isset($_POST['income_score']))
	$income_score = $_POST['income_score'];
if(isset($_POST['unemployment_score']))
	$unemployment_score = $_POST['unemployment_score'];
if(isset($_POST['housing_score']))
	$housing_score = $_POST['housing_score'];
if(isset($_POST['labour_score']))
	$labour_score = $_POST['labour_score'];
if(isset($_POST['climate_score']))
	$climate_score = $_POST['climate_score'];
if(isset($_POST['culture_score']))
	$culture_score = $_POST['culture_score'];
	
$cities = parse_cities();
read_province($cities);
$selectedcity = false;

//get the city info if possible
if(strcmp($cityname, "No City Selected") != 0)
{
	foreach($cities as $city)
	{
		if(strcmp($city->name, $cityname) == 0)
		{
			$selectedcity = $city;
			//echo "$city->name <br/>";
			break;
		}
	}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Electric Sheep: Jason Ernst and Carlos Saavedra">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">
    <title>newRoots by Electric Sheep</title>
    <!-- Bootstrap core CSS -->
    <link href="styles/bootstrap.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="styles/custom.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
     <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAA3zIl-FzUavwu7J_ddxMR7kJdCMOywp0&sensor=false">
    </script>
    <script type="text/javascript">
      function initialize() {
        var mapOptions = { center: new google.maps.LatLng(52.0, -97), zoom: 3, draggable: false };
        var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
<?
	if($selectedcity != false)
	{
		?>
			var markerPos = new google.maps.LatLng(<?=$selectedcity->lat?>,<?=$selectedcity->long?>);
			var destmarker = new google.maps.Marker({position: markerPos,map: map});
		<?
	}
?>        
      }
      google.maps.event.addDomListener(window, 'load', initialize);
    </script>
  </head>

  <body>

    <!-- Fixed navbar -->
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php"><img src="images/newRootsLogo.png"/></a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="index.php">Home</a></li>
            <li><a href="form.php">Find a Match</a></li>
            <li><a href="https://twitter.com/2ElectricSheep">Electric Sheep Twitter Page</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>

    <!-- Begin page content -->
    <div class="container">
    
    <div class="btn-group btn-group-justified">
  <div class="btn-group">
    <button type="button" class="btn btn-default" onClick="window.location.href='form.php';"><span class="glyphicon glyphicon-search"></span>Search</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default" onClick="window.history.back();"><span class="glyphicon glyphicon-list"></span>List</button>
  </div>
  <div class="btn-group">
    <button type="button" class="btn btn-default active"><span class="glyphicon glyphicon-stats"></span>Results</button>
  </div>
</div>
    
    
    <div class="map" id="map-canvas">
    
    </div>
    <div class="row">
    	<div class="col">
        <p class="city"><? if($selectedcity != false) { echo $selectedcity->name; } else { echo $cityname; }?><br />
        <span><? if($selectedcity != false) { echo $selectedcity->province; } ?></span></p>
        
        </div>
        
        <div class="col2">
        <p class="percent"><span class="per"><?=$score?>%</span><br />newRoots Compatibility</p>
        </div>
    </div>
    <div class="row">
    	<div class="col3">
        <div class="icon-container">
        <p><span class="glyphicon glyphicon-usd"></span></p>
        </div>
        
        <p class="icons"><span class="per"><?=$income_score?>%</span><br />Income Compatibility</p>
        
        </div>
        
        <div class="col4">
        <div class="icon-container">
        <p><span class="glyphicon glyphicon-user"></span></p>
        </div>
        <p class="icons"><span class="per"><?=$culture_score?>%</span><br />Cultural Compatibility</p>
        </div>
    
    </div>
    
        <div class="row">
        
            	<div class="col4">
        <div class="icon-container">
        <p><img src="images/sironiconwhite.png"/></p>
        </div>
        <p class="icons"><span class="per"><?=$crime_score?>%</span><br />Crime Compatibility</p>
        
        </div>
        
        <div class="col3">
        <div class="icon-container">
        <p><span class="glyphicon glyphicon-home"></span></p>
        </div>
        <p class="icons"><span class="per"><?=$housing_score?>%</span><br />Housing Compatibility</p>
        </div>
    
    </div>
    
            <div class="row">
    	<div class="col3">
        <div class="icon-container">
        <p><span class="glyphicon glyphicon-briefcase"></span></p>
        </div>
        <p class="icons"><span class="per"><?=$labour_score?>%</span><br />Work Compatibility</p>
        
        </div>
        
        <div class="col4">
        <div class="icon-container">
        <p><span class="glyphicon glyphicon-cloud"></span></p>
        </div>
        <p class="icons"><span class="per"><?=$climate_score?>%</span><br />Climate Compatibility</p>
        </div>
    
    </div>
    
    <div class="rowf">
    	<div class="colf">
        <p class="cityf">Employment Score<br /></p>
        
        </div>
        
        <div class="col2f">
        <p class="percentf"><span class="per"><?=$unemployment_score?>%</span></p>
        </div>
    
    </div>
        
        <div class="alert alert-success"><center>All of the results are evaluated against 33 cities. In all cases, zero is the worst score, and 100 is the best.</center></div>
    
      <div class="page-header">
        <h2>A Nation of Opportunity.</h2>
      </div>
      <p class="lead">We have determined the cities in Canada that will give you the greatest opportunity to succeed as a Canadian citizen. <b>Welcome to Canada!</b></p>
    </div>

    <div id="footer">
      <div class="container">
      
        <p class="text-muted"><img src="images/newRootsLogo.png"/><br />&copy; Copyright Electric Sheep 2014. All Rights Reserved.</p>
      </div>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
    <script src="styles/bootstrap.min.js"></script>
    
    <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-3483823-6', 'jasonernst.com');
  ga('send', 'pageview');

</script>    
        
  </body>
</html>
