<?

$labourdata = "labour-by-industry.csv";
$out = "labour-by-industry-out.csv";
if (($handle = fopen($labourdata, "r")) !== FALSE) 
{
	
	if (($fp = fopen($out, 'w')) !== FALSE)
	{
	
		$last_industry = "";
		
		while (($line = fgets($handle, 1000)) !== FALSE)
		{	
			$data = str_getcsv($line ,",");
			$industry = substr($data[4], 0, strpos($data[4], " (x 1,000)"));
			if(strcmp($industry, $last_industry) != 0)
			{
				fwrite($fp, $line);
				$last_industry = $industry;
			}
		}
		
		fclose($fp);
	}
	fclose($handle);
}
